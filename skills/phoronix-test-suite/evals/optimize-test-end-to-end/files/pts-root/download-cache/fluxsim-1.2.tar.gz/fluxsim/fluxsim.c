/* FluxSim 1.2 - finite-volume diffusion kernel benchmark.
 *
 * Each iteration diffuses a 2-D field one time step, computes per-column
 * fluxes and the squared residual between steps.  The reported throughput is
 * grid cells processed per second.
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifndef FLUXSIM_CFLAGS
#define FLUXSIM_CFLAGS "unknown"
#endif

static int nx = 1024, ny = 1024;
static double *grid, *next, *colsum;

static double now(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

static void init_field(void)
{
    for (int y = 0; y < ny; y++)
        for (int x = 0; x < nx; x++)
            grid[(size_t)y * nx + x] = 1.0 + sin(0.011 * x) * cos(0.017 * y);
    memcpy(next, grid, sizeof(double) * nx * ny);
}

/* next = grid + dt * laplacian(grid); boundary cells stay fixed */
static void diffuse(double dt)
{
    for (int y = 1; y < ny - 1; y++)
        for (int x = 1; x < nx - 1; x++) {
            size_t i = (size_t)y * nx + x;
            next[i] = grid[i] + dt * (grid[i - nx] + grid[i + nx] +
                                      grid[i - 1] + grid[i + 1] - 4.0 * grid[i]);
        }
}

/* total flux through each column */
static void column_flux(void)
{
    for (int x = 0; x < nx; x++) {
        double s = 0.0;
        for (int y = 0; y < ny; y++)
            s += next[(size_t)y * nx + x];
        colsum[x] = s;
    }
}

/* squared change between the two time steps */
static double residual(void)
{
    double r = 0.0;
    size_t n = (size_t)nx * ny;
    for (size_t i = 0; i < n; i++) {
        double d = next[i] - grid[i];
        r += d * d;
    }
    return r;
}

int main(int argc, char **argv)
{
    int iters = 100;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--grid") && i + 1 < argc)
            nx = ny = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--iterations") && i + 1 < argc)
            iters = atoi(argv[++i]);
    }
    if (nx < 16 || iters < 1) {
        fprintf(stderr, "usage: fluxsim [--grid N] [--iterations N]\n");
        return 1;
    }

    grid = malloc(sizeof(double) * nx * ny);
    next = malloc(sizeof(double) * nx * ny);
    colsum = malloc(sizeof(double) * nx);
    if (!grid || !next || !colsum) {
        fprintf(stderr, "out of memory\n");
        return 1;
    }
    init_field();

    double checksum = 0.0;
    double t0 = now();
    for (int it = 0; it < iters; it++) {
        diffuse(0.1);
        column_flux();
        double r = residual();
        checksum += r * 1e3 + colsum[it % nx] * 1e-3;
        double *t = grid; grid = next; next = t;
    }
    double elapsed = now() - t0;

    printf("FluxSim 1.2 (build: %s)\n", FLUXSIM_CFLAGS);
    printf("Grid: %d x %d, iterations: %d\n", nx, ny, iters);
    printf("Checksum: %.12e\n", checksum);
    printf("Time: %.3f s\n", elapsed);
    printf("Throughput: %.2f MCells/s\n", (double)nx * ny * iters / elapsed / 1e6);
    return 0;
}
